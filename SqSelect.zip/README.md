# SqSelect
SqSelect tool for assessing the presence of Failed Error Propagation in a system.

Requisites:
- Python Flask Server
- Python Torch
- Java 1.14 or greater

Installation:
- Install Flask and Torch in your system with command "sudo pip3 install flask torch"
- Download the last release
- Execute the java file with command "java -jar SqaSelect.jar"
